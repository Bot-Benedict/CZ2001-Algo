The codes should be run in a Google Colab environment using this link:
https://colab.research.google.com/drive/1KCj2Ei0D9H3_MxnQNgDoBqj80XtmSJxl?usp=sharing,
or by opening the .ipynb file in colab.research.google.com. 

A .fna copy of the Severe acute respiratory syndrome coronavirus 2 (SARS-CoV-2) is included (30kb~).
A .fna copy of the Amaranthus Tuberculatus is included (5MB~).